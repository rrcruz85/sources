# -*- coding: utf-8 -*-
import oemedical_bariatric_evaluation
import report